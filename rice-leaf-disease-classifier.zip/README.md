
# 🌾 Rice Leaf Disease Classifier

A simple web app built using **Streamlit** and **TensorFlow** to classify rice leaf diseases. Upload an image of a rice leaf and get instant predictions on the disease type.

---

## 🚀 Demo

Try it out locally:

```
streamlit run appp.py
```

---

## 🧠 Model Info

The model used is a fine-tuned deep learning model trained to classify:

- **Bacterial leaf blight**
- **Brown spot**
- **Leaf smut**

Model input size: `128x128`

---

## 🖼️ Sample Interface

![App Screenshot](assets/sample_leaf.jpg)

---

## 📦 Requirements

Install the required packages:

```bash
pip install -r requirements.txt
```

---

## 📁 Files

| File               | Description                                 |
|--------------------|---------------------------------------------|
| `appp.py`          | Streamlit app frontend and backend          |
| `rice_leaf_model.h5` | Trained Keras model for prediction        |
| `requirements.txt` | Dependencies list for installation          |
| `assets/`          | Optional images or media                    |

---

## 🌐 Deployment

You can deploy this app to:
- [Streamlit Cloud](https://streamlit.io/cloud)
- [Render](https://render.com)
- [Hugging Face Spaces](https://huggingface.co/spaces)
- [Heroku](https://www.heroku.com/)

---

## ✍️ Author

**Zain Arshad**  
Feel free to reach out: [LinkedIn](https://www.linkedin.com/in/zainarshad/) | [Email](mailto:mianzainpk450@gmail.com)

---

## 📄 License

This project is licensed under the MIT License.
